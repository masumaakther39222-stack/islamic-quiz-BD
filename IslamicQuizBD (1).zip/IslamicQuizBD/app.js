const questions=[
{question:"ইসলামের প্রথম স্তম্ভ কোনটি?",options:["সালাত","সাওম","শাহাদাহ","যাকাত"],answer:2},
{question:"এক দিনে ফরজ নামাজ কত ওয়াক্ত?",options:["৩ ওয়াক্ত","৪ ওয়াক্ত","৫ ওয়াক্ত","৬ ওয়াক্ত"],answer:2},
{question:"পবিত্র কুরআন কোন মাসে নাজিল হওয়া শুরু হয়?",options:["রমজান","শাওয়াল","মুহররম","রজব"],answer:0},
{question:"মুসলমানদের কিবলা কোনটি?",options:["মসজিদে নববী","কাবা শরীফ","মসজিদুল আকসা","মসজিদে কুবা"],answer:1},
{question:"ইসলামের শেষ নবী কে?",options:["হযরত মূসা (আ.)","হযরত ঈসা (আ.)","হযরত ইব্রাহিম (আ.)","হযরত মুহাম্মদ (সা.)"],answer:3},
{question:"রমজান মাসে মুসলমানরা কোন ইবাদতটি পালন করেন?",options:["হজ","রোজা","কুরবানি","আকিকা"],answer:1},
{question:"পবিত্র কুরআনের প্রথম সূরার নাম কী?",options:["সূরা ইখলাস","সূরা ফাতিহা","সূরা নাস","সূরা বাকারাহ"],answer:1},
{question:"ইসলামের পবিত্রতম মসজিদ কোনটি?",options:["মসজিদে নববী","মসজিদুল আকসা","মসজিদুল হারাম","মসজিদে কুবা"],answer:2},
{question:"যাকাত ইসলামের কত নম্বর স্তম্ভ?",options:["প্রথম","দ্বিতীয়","তৃতীয়","চতুর্থ"],answer:2},
{question:"হজ কোন শহরে পালন করা হয়?",options:["মদিনা","মক্কা","জেরুজালেম","কায়রো"],answer:1}
];
let currentQuestion=0,score=0,answered=false;
const questionElement=document.getElementById("question"),optionsElement=document.getElementById("options"),nextButton=document.getElementById("next-btn"),questionNumber=document.getElementById("question-number"),scoreElement=document.getElementById("score"),progressBar=document.getElementById("progress-bar");
function loadQuestion(){answered=false;nextButton.disabled=true;const q=questions[currentQuestion];questionElement.textContent=q.question;questionNumber.textContent=`প্রশ্ন ${currentQuestion+1}/${questions.length}`;scoreElement.textContent=`স্কোর: ${score}`;progressBar.style.width=`${((currentQuestion+1)/questions.length)*100}%`;optionsElement.innerHTML="";q.options.forEach((option,index)=>{const button=document.createElement("button");button.className="option";button.textContent=option;button.onclick=()=>selectAnswer(index,button);optionsElement.appendChild(button)})}
function selectAnswer(selectedIndex,selectedButton){if(answered)return;answered=true;const correctIndex=questions[currentQuestion].answer;document.querySelectorAll(".option").forEach((button,index)=>{button.classList.add("disabled");if(index===correctIndex)button.classList.add("correct")});if(selectedIndex===correctIndex){score++;selectedButton.classList.add("correct");scoreElement.textContent=`স্কোর: ${score}`}else selectedButton.classList.add("wrong");nextButton.disabled=false}
nextButton.addEventListener("click",()=>{currentQuestion++;if(currentQuestion<questions.length)loadQuestion();else showResult()});
function showResult(){document.getElementById("quiz-container").classList.add("hidden");document.getElementById("result-container").classList.remove("hidden");document.getElementById("final-score").textContent=`${score} / ${questions.length}`;const percentage=score/questions.length*100;document.getElementById("result-message").textContent=percentage===100?"মাশাআল্লাহ! অসাধারণ ফলাফল! 🌟":percentage>=70?"মাশাআল্লাহ! খুব ভালো করেছেন। 👏":percentage>=50?"ভালো করেছেন। আরও একটু পড়াশোনা করুন। 📚":"আরও শেখার চেষ্টা করুন। ইনশাআল্লাহ ভালো করবেন। 🤲"}
function restartQuiz(){currentQuestion=0;score=0;document.getElementById("result-container").classList.add("hidden");document.getElementById("quiz-container").classList.remove("hidden");loadQuestion()}
loadQuestion();